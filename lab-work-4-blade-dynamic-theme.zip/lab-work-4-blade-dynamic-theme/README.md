# Lab Work 4 — Laravel Blade Template Inheritance with a Dynamic Theme

**Assignment requirement:** Create Blade template inheritance using `@yield`, `@extends`, and `@section` to create a dynamic theme.

This submission is an original, responsive creative-studio website called **Atelier Nova**. It uses one shared Blade layout and three pages. A theme chooser switches the whole site between Ocean Blue, Sunset Coral, and Forest Green.

## Files included

```text
lab-work-4-blade-dynamic-theme/
├── routes/
│   └── web.php
├── resources/
│   └── views/
│       ├── layouts/
│       │   └── app.blade.php
│       ├── home.blade.php
│       ├── about.blade.php
│       └── contact.blade.php
├── public/
│   └── css/
│       └── theme.css
├── README.md
└── SUBMISSION_CHECKLIST.txt
```

## How the required Blade directives are used

- **`@yield`** — in `layouts/app.blade.php`, it creates page-specific slots for `title`, `meta_description`, `content`, `head`, and `page_scripts`.
- **`@extends('layouts.app')`** — at the top of `home.blade.php`, `about.blade.php`, and `contact.blade.php`, it makes each page inherit the shared layout.
- **`@section` / `@endsection`** — each page fills the title, description, and main content sections of the layout.
- **Dynamic theme** — the routes validate a `theme` query parameter, the layout applies `theme-ocean`, `theme-sunset`, or `theme-forest` to the body, and CSS variables switch the site's accent colours. Use the theme chooser in the footer to change the theme.

## How to run it in Laravel 10

1. Create a Laravel project if you do not already have one:

   ```bash
   composer create-project laravel/laravel lab-work-4
   ```

2. Copy/merge the included `routes/web.php` into the Laravel project's `routes/web.php`. If you already have routes, keep them and add these route definitions rather than deleting your existing routes.
3. Copy the included `resources/views` folder into the Laravel project's `resources/views` folder, keeping the folder structure.
4. Copy `public/css/theme.css` into the Laravel project's `public/css/theme.css`.
5. In the project folder, run:

   ```bash
   php artisan serve
   ```

6. Open the local URL shown in the terminal, usually `http://127.0.0.1:8000`.

No database or npm build is required for this demo. Google Fonts are optional; the page has fallback fonts if they are unavailable.

## Try the theme options

- `http://127.0.0.1:8000/?theme=ocean`
- `http://127.0.0.1:8000/?theme=sunset`
- `http://127.0.0.1:8000/?theme=forest`

The same `theme` query option works on the About and Contact pages.

## Contact form note

The form uses Laravel's CSRF protection and server-side validation, then displays a confirmation message. It is for demonstrating Blade and validation; it does **not** send email or store messages.
